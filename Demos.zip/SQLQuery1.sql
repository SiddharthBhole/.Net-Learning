--create database IACSDDB

--use IACSDDB;
--create table Emp(No int identity primary key,
--				 Name varchar(50),
--				 Address varchar(50));

--insert into Emp (Name, Address )values ('Mahesh', 'Nagar');
--insert into Emp (Name, Address )values ('Nilesh', 'Panji');
--insert into Emp (Name, Address )values ('Suresh', 'Chennai');

--select * from Emp


